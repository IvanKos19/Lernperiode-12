import json
import string
import random
from flask import Flask, render_template, request, redirect, url_for, flash, abort

app = Flask(__name__)
# Ein Secret Key ist nötig, um 'flash' für Fehlermeldungen zu nutzen (To-Do 3)
app.config['SECRET_KEY'] = 'dein-sehr-geheimer-schluessel' 
JSON_FILE = 'links.json'

# --- Hilfsfunktionen für JSON (To-Do 2) ---

def load_links():
    """Lädt die Links aus der JSON-Datei."""
    try:
        with open(JSON_FILE, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        # Wenn Datei nicht da oder leer, leeres Dict zurückgeben
        return {}

def save_links(links):
    """Speichert das Link-Wörterbuch in der JSON-Datei."""
    with open(JSON_FILE, 'w') as f:
        json.dump(links, f, indent=4)

# --- Hilfsfunktionen für URLs ---

def generate_short_code(length=6):
    """Erzeugt einen zufälligen Kurzcode."""
    chars = string.ascii_letters + string.digits
    code = ''.join(random.choice(chars) for _ in range(length))
    return code

def is_valid_url(url):
    """Einfache URL-Validierung (To-Do 3)."""
    # Dies ist eine einfache Prüfung. Für Produktion könnte man Regex nutzen.
    return url.startswith('http://') or url.startswith('https://')

# --- Routen (Views) ---

@app.route('/')
def index():
    """Zeigt die Startseite mit dem Formular."""
    return render_template('index.html')

@app.route('/shorten', methods=['POST'])
def shorten():
    """Verarbeitet das Formular, erstellt und speichert den Kurzlink."""
    long_url = request.form['url']

    # To-Do 3: Verbesserte Fehlermeldung
    if not is_valid_url(long_url):
        flash('Ungültige URL! Bitte stelle sicher, dass sie mit http:// oder https:// beginnt.', 'error')
        return redirect(url_for('index'))

    links = load_links()

    # (Optional: Prüfen, ob die URL schon gekürzt wurde)
    for code, url in links.items():
        if url == long_url:
            flash(f'Dieser Link wurde bereits gekürzt: {request.host_url}{code}', 'success')
            return redirect(url_for('index'))

    # Neuen Code generieren und auf Kollision prüfen
    short_code = generate_short_code()
    while short_code in links:
        short_code = generate_short_code()

    # To-Do 2: Speicherung in JSON
    links[short_code] = long_url
    save_links(links)

    flash(f'Link erfolgreich gekürzt: {request.host_url}{short_code}', 'success')
    return redirect(url_for('index'))

@app.route('/<short_code>')
def redirect_to_url(short_code):
    """Leitet den Nutzer basierend auf dem Kurzcode weiter."""
    links = load_links()
    long_url = links.get(short_code)

    if long_url:
        return redirect(long_url)
    else:
        # To-Do 3: Fehlerbehandlung, wenn Code nicht existiert
        flash('Kurzlink nicht gefunden!', 'error')
        return redirect(url_for('index'))

# To-Do 1: Funktion, um alle Links anzuzeigen
@app.route('/links')
def list_links():
    """Zeigt eine Liste aller erstellten Kurzlinks."""
    links = load_links()
    # Wir übergeben die host_url, um volle Links im Template bauen zu können
    host = request.host_url 
    return render_template('links.html', links=links, host=host)


if __name__ == '__main__':
    app.run(debug=True)